<template>
  <div>
    <!--面包屑导航-->
    <div class="breadcrumb">
      <div class="container">
        <h2>
          <a href>首页</a>&gt;
          <a href>产品中心</a>&gt;
          <a href>净美仕净化器</a>
        </h2>
      </div>
    </div>
    <!--页面主体-->
    <div class="main container" v-if="data">
      <div class="pd_info clearfloat">
        <div class="pdinfo_img">
          <img :src=" 'http://101.96.128.94:9999/mfresh/' +data.pic" alt />
        </div>
        <div class="pdinfo_text">
          <h2>{{data.title2}}</h2>
          <ul>
            <li>型号：{{data.model}}</li>
            <li>功能：{{data.func}}</li>
            <li>噪音：{{data.noise}}</li>
            <li>风量：{{data.wind}}</li>
            <li>适用对象：{{data.applyTo}}</li>
            <li>适用面积：{{data.size}}</li>
            <li>空气净化能效等级：{{data.level}}</li>
          </ul>
          <p>
            价格：
            <span>¥</span>
            <strong id="price">{{data.price}}</strong>
          </p>
          <a @click="addCart" id="addCart">
            <span class="icon_cart"></span>加入购物车
          </a>
        </div>
      </div>
      <div class="details_box">
        <h2 class="title">产品详情</h2>
        <div class="pd_details" v-html="fullImage(data.detail)">
        </div>
      </div>
    </div>
  </div>
</template>

<script>
export default {
  data() {
    return {
      data: null
    };
  },
  mounted() {
    let pid = this.$route.params.pid;
    this.getData(pid);
  },
  methods: {
    addCart() {
      if (this.$store.state.uid) {
        let url = "cart_detail_add.php";
        let pid = this.data.pid;
        let uid = this.$store.state.uid;
        let params = `pid=${pid}&uid=${uid}`;

        this.axios
          .post(url, params)
          .then(res => {
            console.log(res);
            if (res.data.code == 1) {
              alert("添加成功!");
            } else {
              alert("添加失败!");
            }
          })
          .catch(err => {
            console.error(err);
          });
      } else {
        //如果非登录状态 则跳转到登录页
        alert("只有登录状态才可以添加购物车, 即将跳转登录页!");
        this.$router.push("/login");
      }
    },
    fullImage(html) {
      let baseurl = "http://101.96.128.94:9999/mfresh/";
      return html.replace(/<img src="/g, '<img src="' + baseurl);
    },
    getData(pid) {
      let url = "product_detail.php?pid=" + pid;

      this.axios
        .get(url)
        .then(res => {
          console.log(res);
          this.data = res.data;
        })
        .catch(err => {
          console.error(err);
        });
    }
  }
};
</script>

<style>
</style>